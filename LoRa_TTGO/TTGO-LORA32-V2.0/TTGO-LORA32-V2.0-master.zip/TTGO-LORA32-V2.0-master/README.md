# TTGO-LORA32-V2.0

![images](https://github.com/LilyGO/TTGO-LORA32-V2.0/blob/master/images/T3_2_0.jpg)

![images](https://github.com/LilyGO/TTGO-LORA32-V2.0/blob/master/images/image4.jpg)

![images](https://github.com/LilyGO/TTGO-LORA32-V2.0/blob/master/images/image2.jpg)

![images](https://github.com/LilyGO/TTGO-LORA32-V2.0/blob/master/images/image3.jpg)
