This is derived from https://github.com/G6EJD/ESP32-Weather-Station-using-1.3-OLED
and ported to work with TT GO ESP32 boards.

Other Wunderground API calls that might be intresting:

* [http://api.wunderground.com/api/$APIKEY/conditions/q/US/NYC.json](conditions.json)
* [http://api.wunderground.com/api/$APIKEY/history/q/US/NYC.json](history.json)
* [http://api.wunderground.com/api/$APIKEY/forecast/q/US/NYC.json](forecast.json)
* [http://api.wunderground.com/api/$APIKEY/hourly/q/US/NYC.json](hourly.json)
