#pragma once

/*
 * Put your configuration here.
 */
String apikey   = "";
String country  = "US"; //e.g. "UK";
String city     = "NYC";    //e.g. "LONDON";

const char* host     = "api.wunderground.com";
const char* ssid     = "";
const char* password = "";

